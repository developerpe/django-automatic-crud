from automatic_crud.register import register_models

urlpatterns = []

urlpatterns += register_models()
