from typing import TypeVar

XLS = TypeVar('XLS')
Instance = TypeVar('Instance')
URLList = TypeVar('URLList')
DjangoForm = TypeVar('DjangoForm')
JsonResponse = TypeVar('JsonResponse')